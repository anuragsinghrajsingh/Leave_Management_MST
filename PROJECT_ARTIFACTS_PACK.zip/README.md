# Leave Management MST

<p align="center">
  <sub>A Product of <b>MS Technology</b></sub>
</p>

<p align="center">
  <strong>The Next-Gen, High-Performance Workforce Attendance Ecosystem.</strong>
</p>

<div align="center">

[![Python 3.8+](https://img.shields.io/badge/Python-3.8+-blue?style=for-the-badge&logo=python&logoColor=white)](https://www.python.org/)
[![Django 4.2+](https://img.shields.io/badge/Django-4.2+-092e20?style=for-the-badge&logo=django&logoColor=white)](https://www.djangoproject.com/)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-12+-4169E1?style=for-the-badge&logo=postgresql&logoColor=white)](https://www.postgresql.org/)
[![UI Glassmorphism](https://img.shields.io/badge/UI-Modern--Glass-cyan?style=for-the-badge)](https://github.com/anuragsinghrajsingh/Leave_Management_MST)

</div>

---

## Project Documentation

Start here when working on this project:

| File | Purpose |
|---|---|
| `PROJECT_START_HERE.md` | Quick navigation, production commands, service checks, and emergency debugging flow |
| `PROJECT_GUIDE.md` | Practical operating guide |
| `PROJECT_DEEP_DIVE_BOOK.md` | Full project book with file inventory, function reference, runbooks, matrices, testing recipes, security, and performance notes |

For production deployment, use this order:

```text
changed files -> required command -> service restart -> log check -> browser/admin verification
```

Important production services:

```text
gunicorn
qcluster
lms_scheduler
postgresql
nginx
```

---

## 1. Project Overview

The **Leave Management MST (Modern System Technologies)** Edition is an enterprise-grade web platform for workforce leave tracking, approvals, background email processing, system notifications, audit logging, and scheduled operations.

The project uses Django as the core application layer, PostgreSQL as the production database, Django-Q for queued background jobs, and a dedicated `lms_scheduler` systemd service for recurring production tasks such as backups, weekly reports, public holiday sync, and admin email job recovery.

---

## 2. Table Of Contents

1. [Project Overview](#1-project-overview)
2. [About MST Edition](#3-about-mst-edition)
3. [System Architecture](#4-system-architecture)
4. [Enterprise Features](#5-enterprise-features)
5. [System Workflows](#6-system-workflows)
6. [Directory Structure](#7-directory-structure)
7. [Getting Started](#8-getting-started-local-setup)
8. [Environment Configuration](#9-environment-configuration)
9. [Production Deployment](#10-production-deployment-and-systemd-setup)
10. [Operations Cheatsheet](#11-operations-and-troubleshooting-cheatsheet)
11. [License And Credits](#12-license-and-credits)

---

## 3. About MST Edition

The MST Edition was engineered around a **Clean Core** philosophy: separate business rules into focused service files, keep production services isolated, and make operational workflows auditable.

### MS Technology Pillars

* **Reliability**: Atomic transactions, explicit database locking, recovery jobs, and service checks protect critical workflows.
* **Aesthetics**: Modern UI styling with responsive layouts, glass-like panels, dynamic colors, and polished interactions.
* **Maintainability**: Views and admin actions call service functions instead of hiding business logic inside templates or one-off scripts.

---

## 4. System Architecture

```mermaid
flowchart TB
    Client[Web Browsers / HTTPS] <--> Nginx[Nginx Reverse Proxy]
    Nginx <--> Gunicorn[Gunicorn WSGI Server]
    Gunicorn <--> Django[Django Core Application]

    subgraph Services [Asynchronous Processing Engine]
        Django <--> QCluster[Django-Q Cluster / Worker Pool]
        QCluster -- Fallback --> ThreadPool[ThreadPoolExecutor max_workers=8]
        LMS_Scheduler[LMS Scheduler Daemon] -- Cron Triggers --> Django
    end

    subgraph Database [Storage Layer]
        Django <--> PostgreSQL[(PostgreSQL Database)]
        PostgreSQL -- select_for_update self only --> Django
    end

    subgraph FileSystem [State And Backups]
        LMS_Scheduler -- pg_dump --> ZIP[Compressed ZIP Backups]
        Django -- Write --> Logs[System Logs And Startup State]
    end
```

### Stack Components

* **Core Framework**: Django 4.2 LTS / Python 3.8+
* **Primary Database**: PostgreSQL
* **Background Queue**: Django-Q ORM broker with `ThreadPoolExecutor` fallback
* **Scheduler**: Dedicated APScheduler process via `python manage.py run_lms_scheduler`
* **Web Server**: Nginx + Gunicorn
* **Frontend**: HTML templates, CSS, and JavaScript/AJAX

---

## 5. Enterprise Features

### Dedicated LMS Scheduler Daemon

The scheduler runs as a standalone service:

```bash
python manage.py run_lms_scheduler
```

It handles:

* Nightly backups, daily at 02:00
* Weekly HR PDF reports, Monday at 09:00
* India public holiday sync, monthly on day 1 at 03:00
* Admin email job recovery, every 5 minutes
* Scheduler keepalive, every 6 hours
* Startup catch-up checks for missed backups and weekly reports

### High-Fidelity PDF Reporting

Weekly HR reports use Playwright/Chromium rendering to produce styled PDF reports with attendance and leave metrics.

### Asynchronous Email And Notification Cluster

Bulk administrator emails are tracked through:

```text
AdminEmailJob
AdminEmailJobItem
EmailDeliveryLog
```

Each selected user gets a per-user status: queued, running, sent, failed, or skipped.

### Leave Calculation Engine

Supported leave types:

* **Short Leave**: same-day, max 2 hours, working hours only, max 2/month, deducts 0.25 days.
* **Half Leave**: same-day, max 4 hours, working hours only, max 1/month, deducts 0.5 days.
* **Sick, Earned, Unpaid**: full-day leave types that can span multiple days.

Full-day leaves can interact with WFH bridge rules and public holiday logic. Short and Half leave are time-based and do not use the WFH bridge.

### PostgreSQL Lock Safety

Critical leave approval/rejection uses:

```python
Leave.objects.select_for_update(of=("self",)).select_related("user", "user__profile")
```

This locks only the `Leave` row while still allowing related user/profile data to be read. It avoids the PostgreSQL nullable outer join error:

```text
FOR UPDATE cannot be applied to the nullable side of an outer join
```

### Automated Self-Healing Backups

`manage_backups.py` runs `pg_dump`, compresses successful dumps into `.zip` files, applies retention cleanup, and removes incomplete raw `.sql` files if a backup fails.

---

## 6. System Workflows

### Leave Application And Impact Validation Flow

```mermaid
sequenceDiagram
    participant User as Employee Portal
    participant View as views.apply_leave
    participant DB as PostgreSQL Database
    participant Notify as Notification Services

    User->>View: Submit leave form
    View->>View: Validate date/time/type
    View->>View: Check overlap and holiday rules
    View->>View: Verify Short/Half monthly limits
    View->>View: Compute balance deduction
    alt Valid request
        View->>DB: Create Leave record
        View->>Notify: Notify HR/Admin as needed
        View->>User: Success response
    else Invalid request
        View->>User: Error response
    end
```

### Admin Bulk Email Flow

```text
Admin selects users
-> confirmation page previews actionable/skipped users
-> Admin submits
-> AdminEmailJob is created
-> AdminEmailJobItem rows are created
-> qcluster processes the job
-> live admin job page polls status every 3000ms
-> stale running jobs can be recovered by scheduler
```

---

## 7. Directory Structure

```text
Leave Management/
|-- App/
|   |-- management/
|   |   `-- commands/
|   |       `-- run_lms_scheduler.py
|   |-- services/
|   |   |-- scheduler.py
|   |   |-- startup_checks.py
|   |   |-- admin_bulk_email_jobs.py
|   |   |-- background_tasks.py
|   |   |-- uptime_tracker.py
|   |   `-- public_holidays.py
|   |-- models.py
|   |-- admin.py
|   `-- views.py
|-- leave_management/
|   |-- settings.py
|   `-- urls.py
|-- static/
|-- templates/
`-- manage_backups.py

backups/
logs/
runtime/
PROJECT_START_HERE.md
PROJECT_GUIDE.md
PROJECT_DEEP_DIVE_BOOK.md
README.md
```

---

## 8. Getting Started Local Setup

### Prerequisites

* Python 3.8 or higher
* PostgreSQL 12+
* Virtual environment support

### Setup Steps

Clone the repository:

```bash
git clone https://github.com/anuragsinghrajsingh/Leave_Management_MST.git
cd Leave_Management_MST
```

Create and activate a virtual environment:

```bash
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

Linux/macOS:

```bash
source venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Run migrations:

```bash
python "Leave Management/manage.py" migrate
```

Create a superuser:

```bash
python "Leave Management/manage.py" createsuperuser
```

Run the web server:

```bash
python "Leave Management/manage.py" runserver
```

Run the queue in a separate terminal:

```bash
python "Leave Management/manage.py" qcluster
```

Run the scheduler in a separate terminal:

```bash
python "Leave Management/manage.py" run_lms_scheduler
```

---

## 9. Environment Configuration

Create a `.env` file in the project root.

Example:

```ini
SECRET_KEY=your_secure_secret_key
DEBUG=True
ALLOWED_HOSTS=127.0.0.1,localhost,yourdomain.com

DATABASE_URL=postgres://db_user:db_password@127.0.0.1:5432/db_name

EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_USE_SSL=False
EMAIL_HOST_USER=notifications@yourdomain.com
EMAIL_HOST_PASSWORD=your_app_specific_smtp_password
DEFAULT_FROM_EMAIL=Leave Management <notifications@yourdomain.com>

PORTAL_BASE_URL=http://127.0.0.1:8000

LMS_Q_WORKERS=2
LMS_Q_TIMEOUT=120
LMS_Q_RETRY=300
LMS_Q_QUEUE_LIMIT=100
LMS_Q_BULK=20

LMS_SKIP_UPTIME_RECORD=0
```

Never commit real `.env` secrets.

---

## 10. Production Deployment And Systemd Setup

Production should run these services:

```text
gunicorn
qcluster
lms_scheduler
postgresql
nginx
```

Each Python service should have a PATH that includes the virtual environment first and `/usr/bin` for system tools:

```text
PATH=/home/mstleave/Leave_Management_MST/venv/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
```

Check service PATH:

```bash
sudo systemctl show gunicorn -p Environment
sudo systemctl show qcluster -p Environment
sudo systemctl show lms_scheduler -p Environment
```

Service administration:

```bash
sudo systemctl daemon-reload
sudo systemctl enable gunicorn qcluster lms_scheduler
sudo systemctl restart gunicorn qcluster lms_scheduler
sudo systemctl status gunicorn qcluster lms_scheduler
```

After deploying changed files:

```bash
python manage.py check
```

If migrations changed:

```bash
python manage.py migrate
```

If static files changed:

```bash
python manage.py collectstatic
```

---

## 11. Operations And Troubleshooting Cheatsheet

### Logs

```bash
sudo journalctl -u gunicorn -n 120 --no-pager
sudo journalctl -u qcluster -n 120 --no-pager
sudo journalctl -u lms_scheduler -n 120 --no-pager
```

Specific time:

```bash
sudo journalctl -u lms_scheduler --since "2026-05-31 01:55:00" --no-pager
```

### Backup Checks

```bash
ls -lh ~/Leave_Management_MST/backups | tail -20
which pg_dump
which psql
pg_dump --version
psql --version
```

Check catch-up status:

```bash
python manage.py shell -c "from App.services.startup_checks import get_backup_catchup_status; print(get_backup_catchup_status())"
```

### Q Cluster Process Count

```bash
pgrep -af "manage.py qcluster"
pgrep -fc "manage.py qcluster"
```

Multiple qcluster processes are normal.

### Playwright Check

```bash
python -c "from playwright.sync_api import sync_playwright; p=sync_playwright().start(); b=p.chromium.launch(headless=True); print('playwright chromium ok'); b.close(); p.stop()"
```

### Production Debugging Rule

```text
1. Identify exact user action.
2. Identify exact timestamp.
3. Check the owning service log.
4. Search PROJECT_DEEP_DIVE_BOOK.md.
5. Search source code with rg.
6. Fix code.
7. Run python manage.py check.
8. Run migrate/collectstatic only if needed.
9. Restart the correct service.
10. Verify in browser/admin/logs.
```

---

## 12. License And Credits

* **License**: Proprietary - All Rights Reserved.
* **Author**: Anurag Singh Raj Singh ([anuragsinghrajsingh@gmail.com](mailto:anuragsinghrajsingh@gmail.com))
* **Copyright**: 2026 MS Technology. Engineering the Future of Work.

